#!/usr/bin/env bash
set -euo pipefail
sudo python3 -m pip install --upgrade pip
sudo python3 -m pip install astropy==6.0.1 boto3>=1.28.0
