# Phase 4a Validation Report

**Generated**: 2026-01-20T03:49:09.986910

**Manifests S3**: `s3://darkhaloscope/phase4_pipeline/phase4a/v3_color_relaxed/manifests`

## Summary

- **Total Experiments**: 3
- **Total Tasks**: 337,223,482
- **Total Issues**: 0

## Experiment Details


### debug_stamp64_bandsgrz_gridgrid_small

- **Rows**: 792,192
- **Valid**: True
- **Splits**: {'train': 249312, 'test': 267840, 'val': 275040}
- **Unique Bricks**: 6,331
- **Unique Regions**: 376

### grid_stamp64_bandsgrz_gridgrid_medium

- **Rows**: 325,782,720
- **Valid**: True
- **Splits**: {'test': 110720160, 'train': 93886560, 'val': 121176000}
- **Unique Bricks**: 126,921
- **Unique Regions**: 740

### train_stamp64_bandsgrz_gridgrid_small

- **Rows**: 10,648,570
- **Valid**: True
- **Splits**: {'train': 2768516, 'test': 3681570, 'val': 4198484}
- **Unique Bricks**: 254,028
- **Unique Regions**: 800
