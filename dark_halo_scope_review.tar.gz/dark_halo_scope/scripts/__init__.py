"""
Scripts for dark_halo_scope project.

Entry-point scripts for each phase of the project.
"""

